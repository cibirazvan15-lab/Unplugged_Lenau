# Unplugged — Lenau

Landing page for Unplugged, the acoustic music club at Nikolaus-Lenau-Schule.

Single self-contained file (`index.html`) — no build step, no dependencies to install.

## Run locally

Just open `index.html` in a browser.

## Publish with GitHub Pages

1. Create a new repo on GitHub (e.g. `unplugged-lenau`) and push this folder:
   ```bash
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/unplugged-lenau.git
   git push -u origin main
   ```
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Save — GitHub gives you a URL like `https://<your-username>.github.io/unplugged-lenau/` within a minute or two.

## Edit content

All copy, colors, and schedule live directly in `index.html` — search for the `<section>` you want to change (`#about`, `#sessions`, `#join`).
